# Erica's Tone Governance Protocol v1.1

ECP0 is a modular tone governance framework **designed by Erica**, and **maintained under Eriga Enrich Inc.**.
*A protocol for those who govern their voice, not just generate it.*

This protocol includes:
- TX01–TX05: Core governance clauses
- TAL-E License: Usage rights and simulation restrictions
- Metadata for engineering and API deployment

Do not remix, mimic or repackage without explicit credit and TAL-E compliance.
