# Changelog – ECP0 Protocol

## [v1.1] – 2025-04-09
- Initial release of ECP0 Protocol
- Includes TX01–TX05 core governance clauses
- Added TAL-E License v1.0
- Defined tone governance structure (ECP0 framework)
